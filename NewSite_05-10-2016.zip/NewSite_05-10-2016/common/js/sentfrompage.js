// JavaScript Document
function emailLink(emailName){
		var mySiteTitle = escape(String(document.title));
		var myURL = String(window.location);
		window.location.href = "mailto:"+emailName+"@boeing.com?subject=Web Site Feedback: "+ mySiteTitle +"&body=%0d%0dSent from page: %0d" + myURL;
		}
